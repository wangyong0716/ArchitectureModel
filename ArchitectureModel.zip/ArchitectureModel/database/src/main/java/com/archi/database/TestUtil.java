package com.archi.database;

import android.util.Log;

public class TestUtil {

    public static void log() {
        Log.i("QQQ", "test log");
    }
}
